#coding = utf-8
BASE_URL="http://httpbin.org/"
IP_URL="/ip"
LOCAL_IP="171.91.129.136"
POST_TEST_URL= "/post"