#coding = utf-8
BASE_URL="http://httpbin.org/"
IP_URL="/ip"
LOCAL_IP="171.91.131.82"
POST_TEST_URL= "/post"